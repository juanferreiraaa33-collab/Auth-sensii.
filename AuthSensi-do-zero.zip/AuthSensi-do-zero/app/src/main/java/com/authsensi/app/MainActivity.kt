package com.authsensi.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(8, 13, 16)
    private val panel = Color.rgb(17, 26, 31)
    private val turquoise = Color.rgb(53, 214, 208)
    private val key = "nxnbghse"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showLogin()
    }

    private fun baseLayout() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setPadding(28, 32, 28, 32)
        setBackgroundColor(bg)
    }

    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
    }

    private fun showLogin() {
        val root = baseLayout()
        val title = TextView(this).apply {
            text = "AUTH SENSI"
            textSize = 30f
            setTextColor(turquoise)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Digite sua Key para continuar"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 28)
        }
        val input = EditText(this).apply {
            hint = "Sua Key"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 16f
            singleLine = true
            setPadding(18, 14, 18, 14)
            background = rounded(panel, 18f)
        }
        val enter = Button(this).apply {
            text = "VALIDAR ACESSO"
            isAllCaps = false
            textSize = 16f
            setTextColor(bg)
            background = rounded(turquoise, 18f)
            setOnClickListener {
                if (input.text.toString().trim() == key) showHome()
                else Toast.makeText(this@MainActivity, "Key inválida", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(subtitle, LinearLayout.LayoutParams(-1, -2))
        root.addView(input, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 16 })
        root.addView(enter, LinearLayout.LayoutParams(-1, 54))
        setContentView(root)
    }

    private fun showHome() {
        val root = baseLayout()
        val title = TextView(this).apply {
            text = "AUTH SENSI"
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(turquoise)
            gravity = Gravity.CENTER
        }
        val message = TextView(this).apply {
            text = "Acesso autorizado!\n\nEsta é a base do aplicativo. Vamos adicionar as funções por etapas."
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        val back = Button(this).apply {
            text = "SAIR"
            isAllCaps = false
            setOnClickListener { showLogin() }
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(message, LinearLayout.LayoutParams(-1, -2))
        root.addView(back, LinearLayout.LayoutParams(-1, 54))
        setContentView(root)
    }
}
