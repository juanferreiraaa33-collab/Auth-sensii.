AUTH SENSI — projeto inicial

Android nativo em Kotlin. Tema preto + azul-turquesa.
Key fixa da primeira versão: nxnbghse.
Compilação: Android Gradle Plugin 8.7.3, Gradle 8.9 e Java 17.
A Key é um bloqueio simples local, não autenticação segura contra análise do APK.
